console.log("Welcome to The Ultimate jQuery Course!🚀");
